# Expand the code below, so that you can collect an input from the user to work out their
# year of birth if you collect their current age. Collect the age as a float. 
# Express the year born as an integer. Save as yearBornCalculator.py 

# collect age input from user



age = input("Please enter your age: ") 
year = 2021
yearborn = 2021 - int(age) 
print ("your born year in: " + str(yearborn))
