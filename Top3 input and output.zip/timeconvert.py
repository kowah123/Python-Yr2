# Enhance the TimeConverter program so that it collects a decimal value 
# (called hrsEntered) of hours from the user, then converts it 
# and displays a message that states.
# hrsEntered Hours = nn Hours, nn Minutes and nn Seconds
# 

# type hours with a decimal point: 6.37
# 6.37 Hours = 6 Hours 22 minutes and 12 seconds


hours = float(input("hrsEntered hours: "))

hours = int (input("60 hours = 22 minutes = 12 seconds"))

# print("hours : %d \nminutes: %d  \ntime: %d " % ( hour, minutes, seconds))

print ("hours")

